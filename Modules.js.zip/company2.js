import {company,getCompany} from './company1.js'

console.log(company)
console.log(getCompany())